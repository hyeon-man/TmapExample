package kr.ac.kopo.tmapexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TmapExampleApplicationTests {

    @Test
    void contextLoads() {
    }

}
